import os
import time
from colorama import Fore, Style

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear()
    print(Fore.CYAN + Style.BRIGHT + """
██████╗  █████╗ ██████╗ ██╗  ██╗████████╗██████╗ 
██╔══██╗██╔══██╗██╔══██╗██║  ██║╚══██╔══╝██╔══██╗
██║  ██║███████║██████╔╝███████║   ██║   ██████╔╝
██║  ██║██╔══██║██╔═══╝ ██╔══██║   ██║   ██╔═══╝ 
██████╔╝██║  ██║██║     ██║  ██║   ██║   ██║     
╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝   ╚═╝   By DarkTr4ce
""" + Style.RESET_ALL)

def menu():
    banner()
    print(Fore.RED + "[1]" + Fore.WHITE + " Bruteforce WordPress V1")
    print(Fore.RED + "[2]" + Fore.WHITE + " Bruteforce WordPress v2")
    print(Fore.RED + "[3]" + Fore.WHITE + " Bruteforce WordPress v3")
    print(Fore.RED + "[0]" + Fore.WHITE + " Keluar")
    print()
    pilih = input(Fore.CYAN + "Pilih opsi: " + Fore.WHITE)

    if pilih == '1':
       os.system("python modules/bfwp.py")
    elif pilih == '2':
       os.system("python modules/p.py")
    elif pilih == '3':
       os.system("python modules/brutewp.py")
    elif pilih == '0':
        exit()
    else:
        print(Fore.YELLOW + "Opsi tidak valid!")
        time.sleep(1)
        menu()

if __name__ == '__main__':
    menu()
