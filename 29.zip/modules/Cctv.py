#!/usr/bin/env python3
# -- coding: utf-8 --

import requests
import re
import os
import colorama
from requests.structures import CaseInsensitiveDict
from colorama import Fore, Style
os.system('clear')
colorama.init(autoreset=True)

url = "http://www.insecam.org/en/jsoncountries/"

headers = CaseInsensitiveDict()
headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
headers["Cache-Control"] = "max-age=0"
headers["Connection"] = "keep-alive"
headers["Host"] = "www.insecam.org"
headers["Upgrade-Insecure-Requests"] = "1"
headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"

resp = requests.get(url, headers=headers)

data = resp.json()
countries = data['countries']

print(Fore.RED + Style.BRIGHT + """
   SC HEK CCTV BY INFERNALXPLOIT
   Author : InfernalXploit
   Pembuat : InfernalXploit
   Nomer WhatsApp : 6289648191199""")

print(Fore.YELLOW + " 📡 CCTV Scanner By InfernalXploit \n")

for key, value in countries.items():
    print(Fore.GREEN + f'Code: ({key}) - {value["country"]} ({value["count"]} cameras)')

print("")

try:
    country = input(Fore.CYAN + "Masukkan kode negara (##): " + Fore.YELLOW).strip()
    
    res = requests.get(f"http://www.insecam.org/en/bycountry/{country}", headers=headers)
    last_page = re.findall(r'pagenavigator\("\?page=", (\d+)', res.text)[0]

    for page in range(int(last_page)):
        res = requests.get(
            f"http://www.insecam.org/en/bycountry/{country}/?page={page}",
            headers=headers
        )
        find_ip = re.findall(r"http://\d+\.\d+\.\d+\.\d+:\d+", res.text)
        for ip in find_ip:
            print(Fore.BLUE + ip)
except Exception as e:
    print(Fore.RED + f"Error: {e}")
