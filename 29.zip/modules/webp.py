import os
import requests
import random
from colorama import Fore, Style, init

init(autoreset=True)
os.system('clear' if os.name != 'nt' else 'cls')

# Banner
banner = f"""{Fore.RED}
 ███████╗███╗   ██╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗     ██╗  ██╗██████╗
 ██╔════╝████╗  ██║██╔════╝██╔══██╗████╗  ██║██╔══██╗██║     ██║  ██║██╔══██╗
 █████╗  ██╔██╗ ██║█████╗  ██████╔╝██╔██╗ ██║███████║██║     ███████║██████╔╝
 ██╔══╝  ██║╚██╗██║██╔══╝  ██╔═══╝ ██║╚██╗██║██╔══██║██║     ██╔══██║██╔═══╝
 ███████╗██║ ╚████║███████╗██║     ██║ ╚████║██║  ██║███████╗██║  ██║██║
 ╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝     ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝
{Style.RESET_ALL}
           {Fore.CYAN}>> Spam Brutality Web Phising By InfernalXploit <<{Style.RESET_ALL}
"""

print(banner)

# Input data
nama_email = input(f"{Fore.CYAN}[?] Masukkan nama email (cth: rendi): {Style.RESET_ALL}")
domain = "@gmail.com"
password_input = input(f"{Fore.CYAN}[?] Masukkan password yang akan dikirim: {Style.RESET_ALL}")
url = input(f"{Fore.CYAN}[?] Masukkan URL target (cth: https://site.com/login.php): {Style.RESET_ALL}")

try:
    jumlah = int(input(f"{Fore.CYAN}[?] Masukkan jumlah pengiriman: {Style.RESET_ALL}"))
except ValueError:
    print(f"{Fore.RED}[!] Jumlah tidak valid.{Style.RESET_ALL}")
    exit()

user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)...",
    "Mozilla/5.0 (Linux; Android 10; SM-G970F)...",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)...",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64)..."
]

# Kirim data palsu
for i in range(jumlah):
    email = f"{nama_email}{i}{domain}"
    headers = {
        "User-Agent": random.choice(user_agents),
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "email": email,
        "password": password_input
    }

    try:
        res = requests.post(url, data=data, headers=headers, timeout=10)
        if res.status_code == 200:
            print(f"{Fore.GREEN}[{i+1}/{jumlah}] SUCCESS{Style.RESET_ALL} - {email}")
        else:
            print(f"{Fore.RED}[{i+1}/{jumlah}] GAGAL{Style.RESET_ALL} - Status: {res.status_code}")
    except Exception as e:
        print(f"{Fore.RED}[{i+1}/{jumlah}] ERROR{Style.RESET_ALL} - {e}")
