#!/bin/bash

# Warna
cyan='\e[36m'
white='\e[37m'
red='\e[31m'
reset='\e[0m'

clear
echo -e "${cyan}╔══════════════════════════════════════╗"
echo -e "${white}║    InfernalXploit Bash Encoder       ║"
echo -e "${red}║       Powered by DarkTr4ce           ║"
echo -e "${cyan}╚══════════════════════════════════════╝${reset}"

read -p "$(echo -e ${white}[?] Masukkan file .sh yang ingin diencode: ${reset})" input
if [[ ! -f "$input" ]]; then
    echo -e "${red}[!] File tidak ditemukan!${reset}"
    exit 1
fi

read -p "$(echo -e ${white}[?] Nama output file (.sh): ${reset})" output
if [[ "${output: -3}" != ".sh" ]]; then
    echo -e "${red}[!] Output harus berekstensi .sh${reset}"
    exit 1
fi

encoded=$(base64 "$input" | tr -d '\n')
echo "#!/bin/bash" > "$output"
echo "eval \"\$(echo $encoded | base64 -d)\"" >> "$output"

chmod +x "$output"
echo -e "${green}[✓] Berhasil encode! Output: $output${reset}"
