import requests, os
from urllib.parse import quote

MERAH = '\033[91m'
HIJAU = '\033[92m'
PUTIH = '\033[97m'
RESET = '\033[0m'

API_KEY = "6NAT7AN-PZF4MYT-PWQJMDS-YRCJTBF"

def banner():
    os.system("clear")
    print(f"""{MERAH}
██████╗ ███████╗ █████╗ ██╗      ███████╗███████╗
██╔══██╗██╔════╝██╔══██╗██║      ██╔════╝██╔════╝
██████╔╝█████╗  ███████║██║█████╗███████╗███████╗
██╔══██╗██╔══╝  ██╔══██║██║╚════╝╚════██║╚════██║
██║  ██║███████╗██║  ██║███████╗ ███████║███████║
╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝ ╚══════╝╚══════╝
{PUTIH}InfernalXploit - REALTIME SCREENSHOT
{HIJAU}Output disimpan ke: /sdcard/screenshoot/{RESET}
""")

def simpan_screenshot(url):
    if not url.startswith("http"):
        url = "https://" + url

    safe_url = quote(url, safe='')
    filename = url.replace("https://", "").replace("http://", "").replace("/", "_") + ".png"
    output_path = "/sdcard/screenshoot"
    os.makedirs(output_path, exist_ok=True)
    full_path = os.path.join(output_path, filename)

    api_url = (
        f"https://shot.screenshotapi.net/screenshot"
        f"?token={API_KEY}&url={safe_url}"
        f"&output=image&file_type=png&wait_for_event=load&dark_mode=false&delay=1000"
    )

    print(f"{PUTIH}[•] Screenshot: {url}{RESET}")
    try:
        r = requests.get(api_url, stream=True, timeout=60)
        if r.status_code == 200 and "image" in r.headers.get("Content-Type", ""):
            with open(full_path, 'wb') as f:
                for chunk in r.iter_content(1024):
                    f.write(chunk)
            print(f"{HIJAU}[✓] Disimpan: {full_path}{RESET}")
        else:
            print(f"{MERAH}[X] Gagal screenshot: {url} (Status {r.status_code}){RESET}")
    except Exception as e:
        print(f"{MERAH}[X] Error: {e}{RESET}")

def menu():
    banner()
    print(f"""{PUTIH}
[1] Screenshot 1 Website
[2] Screenshot Massal dari File
[3] Keluar
{RESET}""")
    pilih = input(f"{HIJAU}>>> Pilih menu: {RESET}")
    if pilih == "1":
        url = input(f"{PUTIH}[?] Masukkan URL/domain: {RESET}")
        simpan_screenshot(url)
    elif pilih == "2":
        file = input(f"{PUTIH}[?] Masukkan nama file list domain: {RESET}")
        try:
            with open(file, 'r') as f:
                for line in f:
                    simpan_screenshot(line.strip())
        except:
            print(f"{MERAH}[X] Gagal membaca file.{RESET}")
    elif pilih == "3":
        print(f"{MERAH}[!] Keluar...{RESET}")
        exit()
    else:
        print(f"{MERAH}[X] Pilihan salah!{RESET}")

if __name__ == "__main__":
    os.system("termux-setup-storage")
    menu()
