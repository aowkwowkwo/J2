// File: infernal-encoder.js
const fs = require("fs");
const readline = require("readline");
const os = require("os");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const clear = () => {
  if (os.platform() === "win32") {
    require("child_process").execSync("cls", { stdio: 'inherit' });
  } else {
    require("child_process").execSync("clear", { stdio: 'inherit' });
  }
};

const banner = () => {
  console.log(`
\x1b[36m╔══════════════════════════════════════╗
║\x1b[37m   InfernalXploit JavaScript Encode   \x1b[36m║
║\x1b[37m     Encode .js ke Base64 + Eval      \x1b[36m║
║\x1b[31m       Coded by InfernalXploit        \x1b[36m║
╚══════════════════════════════════════╝\x1b[0m
`);
};

const ask = (q) => new Promise(resolve => rl.question(q, resolve));

(async () => {
  clear();
  banner();

  const input = await ask("\x1b[37m[?] Masukkan file JavaScript yang ingin diencode: \x1b[0m");
  if (!fs.existsSync(input)) {
    console.log("\x1b[31m[!] File tidak ditemukan!\x1b[0m");
    process.exit();
  }

  const output = await ask("\x1b[37m[?] Masukkan nama file output (.js): \x1b[0m");
  if (!output.endsWith(".js")) {
    console.log("\x1b[31m[!] Output harus berformat .js\x1b[0m");
    process.exit();
  }

  const raw = fs.readFileSync(input, "utf-8");
  const encoded = Buffer.from(raw).toString("base64");

  const final = `eval(atob("${encoded}"));`;
  fs.writeFileSync(output, final);

  console.log(`\x1b[32m[✓] Berhasil diencode! Output disimpan di: ${output}\x1b[0m`);
  rl.close();
})();
