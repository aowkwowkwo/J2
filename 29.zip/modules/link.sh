#!/bin/bash

clear
echo -e "\e[31m"
echo "████████╗██╗███╗   ██╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗     ██╗██████╗ "
echo "╚══██╔══╝██║████╗  ██║██╔════╝██╔══██╗████╗  ██║██╔══██╗██║     ██║██╔══██╗"
echo "   ██║   ██║██╔██╗ ██║█████╗  ██████╔╝██╔██╗ ██║███████║██║     ██║██║  ██║"
echo "   ██║   ██║██║╚██╗██║██╔══╝  ██╔═══╝ ██║╚██╗██║██╔══██║██║     ██║██║  ██║"
echo "   ██║   ██║██║ ╚████║███████╗██║     ██║ ╚████║██║  ██║███████╗██║██████╔╝"
echo "   ╚═╝   ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝     ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚═╝╚═════╝ "
echo -e "\e[32m                       INFERNALX SHORTLINK SYSTEM"
echo -e "\e[0m"

read -p "Masukkan Link Asli: " url
if [[ -z "$url" ]]; then
  echo -e "[\e[31mERROR\e[0m] Link tidak boleh kosong!"
  exit 1
fi

encoded_url=$(printf %s "$url" | jq -sRr @uri)

echo -e "\n[\e[34mINFO\e[0m] Memproses link..."

declare -a services=(
  "tinyurl=https://tinyurl.com/api-create.php?url="
  "is.gd=https://is.gd/create.php?format=simple&url="
  "v.gd=https://v.gd/create.php?format=simple&url="
  "da.gd=https://da.gd/s?url="
)

for item in "${services[@]}"; do
  name="${item%%=*}"
  link="${item#*=}"
  short=$(curl -s "${link}${encoded_url}")

  if [[ $short == http* ]]; then
    echo -e "[\e[32m$name\e[0m] => \e[36m$short\e[0m"
  else
    echo -e "[\e[31m$name\e[0m] => Gagal"
  fi
done

echo -e "\n[\e[34mDONE\e[0m] Semua link selesai diproses!"
