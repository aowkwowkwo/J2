import requests
import os
from colorama import Fore, Style, init
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor

init(autoreset=True)

# Warna
T = Fore.CYAN  # Tosca
R = Fore.RED
W = Fore.WHITE

# Clear + Banner
def banner():
    os.system("clear")
    print(f"""{T}
███████╗███╗   ██╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗     
██╔════╝████╗  ██║██╔════╝██╔══██╗████╗  ██║██╔══██╗██║     
█████╗  ██╔██╗ ██║█████╗  ██║  ██║██╔██╗ ██║███████║██║     
██╔══╝  ██║╚██╗██║██╔══╝  ██║  ██║██║╚██╗██║██╔══██║██║     
███████╗██║ ╚████║███████╗██████╔╝██║ ╚████║██║  ██║███████╗
╚══════╝╚═╝  ╚═══╝╚══════╝╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝
       {W}POWERED BY {R}Infernal{T}Xploit{W} | URL SCANNER 2025
""")

headers = {'User-Agent': 'Mozilla/5.0'}

def cek_url(url):
    try:
        r = requests.head(url, allow_redirects=True, timeout=10, headers=headers)
        final_url = r.url
        status = r.status_code
        note = ""
        if status == 200:
            if "porn" in final_url or "scam" in final_url or "jj62z.com" in final_url or "redirect" in final_url:
                note = f"{R}⚠️ Mencurigakan"
            else:
                note = f"{T}✅ Aktif"
        elif status in [301, 302]:
            note = f"{W}➡️ Redirect → {final_url}"
        else:
            note = f"{R}❌ Status: {status}"
    except Exception as e:
        final_url = "-"
        note = f"{R}❌ Gagal konek"
    print(f"{W}[{T}+{W}] {url} → {final_url} [{note}]")
    with open("hasil_scan_url.txt", "a") as f:
        f.write(f"{url} → {final_url} [{note}]\n")

def input_manual():
    url = input(f"{W}[{T}?{W}] Masukkan URL: ").strip()
    cek_url(url)

def input_file():
    try:
        with open("link.txt", "r") as f:
            urls = [line.strip() for line in f if line.strip()]
        print(f"\n{W}[{T}•{W}] Total: {len(urls)} link\n")
        with ThreadPoolExecutor(max_workers=10) as exe:
            exe.map(cek_url, urls)
    except FileNotFoundError:
        print(f"{R}[!] File 'link.txt' tidak ditemukan!")

def menu():
    banner()
    print(f"{W}[1] Scan 1 URL\n[2] Scan dari file link.txt\n")
    pilih = input(f"{W}[{T}?{W}] Pilih opsi: ")
    if pilih == "1":
        input_manual()
    elif pilih == "2":
        input_file()
    else:
        print(f"{R}[!] Pilihan tidak valid.")

if __name__ == "__main__":
    menu()
