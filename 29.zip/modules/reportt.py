#!/usr/bin/env python3
# coding=utf-8

import os
import sys
import time
import random
import requests
from urllib3.exceptions import InsecureRequestWarning

# Disable SSL warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
os.system('clear')
# ANSI Color Codes
COLORS = {
    'RED': '\033[91m',
    'GREEN': '\033[92m',
    'YELLOW': '\033[93m',
    'BLUE': '\033[94m',
    'PURPLE': '\033[95m',
    'CYAN': '\033[96m',
    'WHITE': '\033[97m',
    'RESET': '\033[0m'
}

def cprint(text, color=None, end='\n'):
    if color in COLORS:
        print(f"{COLORS[color]}{text}{COLORS['RESET']}", end=end)
    else:
        print(text, end=end)

def banner():
    print(COLORS['RED'] + """
 █████╗ ██╗   ██╗███╗   ██╗████████╗ █████╗ ██╗     
██╔══██╗██║   ██║████╗  ██║╚══██╔══╝██╔══██╗██║     
███████║██║   ██║██╔██╗ ██║   ██║   ███████║██║     
██╔══██║██║   ██║██║╚██╗██║   ██║   ██╔══██║██║     
██║  ██║╚██████╔╝██║ ╚████║   ██║   ██║  ██║███████╗
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝╚══════╝
""" + COLORS['RESET'])
    print(COLORS['CYAN'] + "    SC BY INFERNALXPLOIT")
    print("   Author : InfernalXploit")
    print("   Pembuat : InfernalXploit")
    print("   Nomer WhatsApp : 6289648191199" + COLORS['RESET'])
    print("="*50 + "\n")

def load_resources():
    proxies = []
    user_agents = []
    
    try:
        with open("proxy1.txt", "r") as f:
            proxies = [proxy.strip() for proxy in f.readlines() if proxy.strip()]
    except:
        proxies = []
    
    try:
        with open("useragents.txt", "r") as f:
            user_agents = [ua.strip() for ua in f.readlines() if ua.strip()]
    except:
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1"
        ]
    
    return proxies, user_agents

def get_instagram_session():
    session = requests.Session()
    session.headers.update({
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://www.instagram.com',
        'Referer': 'https://www.instagram.com/',
        'Connection': 'keep-alive'
    })
    return session

def send_report(session, username, user_agent):
    try:
        session.headers.update({'User-Agent': user_agent})
        home_page = session.get('https://www.instagram.com/', timeout=10)
        
        if 'csrftoken' not in session.cookies:
            return False
        
        report_url = f'https://www.instagram.com/users/{username}/report/'
        session.headers.update({
            'X-CSRFToken': session.cookies['csrftoken'],
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/x-www-form-urlencoded'
        })
        
        form_data = {
            'source_name': '',
            'reason_id': 1,  # 1 = Spam
            'frx_context': ''
        }
        
        response = session.post(report_url, data=form_data, timeout=10)
        return response.status_code == 200
        
    except Exception:
        return False

def main():
    banner()
    proxies, user_agents = load_resources()
    
    username = input("Enter target username: ").strip()
    if not username:
        cprint("Username cannot be empty!", 'RED')
        return
    
    try:
        report_count = int(input("Number of reports to send (1-100): "))
        report_count = max(1, min(100, report_count))  # Batas antara 1-100
    except:
        cprint("Invalid number! Using default (5)", 'YELLOW')
        report_count = 5
    
    cprint(f"\nPreparing to send {report_count} reports to {username}...\n", 'YELLOW')
    
    successful_reports = 0
    failed_reports = 0
    
    for i in range(1, report_count + 1):
        session = get_instagram_session()
        user_agent = random.choice(user_agents)
        
        cprint(f"Report #{i} {username} ", 'CYAN', end='')

        if send_report(session, username, user_agent):
            cprint("SUCCESS", 'GREEN')
            successful_reports += 1
        else:
            cprint("FAILED", 'RED')
            failed_reports += 1
        
        if i < report_count:
            delay = random.uniform(3, 8)
            time.sleep(delay)
    
    print("\n" + "="*50)
    cprint("REPORT SUMMARY:", 'PURPLE')
    cprint(f"Target: {username}", 'WHITE')
    cprint(f"Attempted reports: {report_count}", 'WHITE')
    cprint(f"Successful reports: {successful_reports}", 'GREEN')
    cprint(f"Failed reports: {failed_reports}", 'RED' if failed_reports > 0 else 'GREEN')
    print("="*50)

if __name__ == "__main__":
    main()
